package prjCarro;

public class Carro {

	// Atributos
	String marca;
	String modelo;
	String placa;
	int V;

	// Construtores
	public Carro() {

	}

	public Carro(String marca, String modelo, String placa, int V) {
		this.marca = marca;
		this.modelo = modelo;
		this.placa = placa;
		this.V = V;
	}

	// Getter e Setter
	public String getMarca() {
		return marca;
	}

	public void setMarca(String Marca) {
		this.marca = marca;
	}

	// Getter e Setter
	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	// Getter e Setter
	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	// Getter e Setter
	public int getV() {
		return V;
	}

	public void setV(int v) {
		if (V < 0) {
			System.out.println("Velocidade não pode ser negativa!");
			this.V = 0;
		} else {
			this.V = V;
		}
	}

	// Método (acelerar)
	void acelerar(int acelerar) {
		V += acelerar;
	}
}
