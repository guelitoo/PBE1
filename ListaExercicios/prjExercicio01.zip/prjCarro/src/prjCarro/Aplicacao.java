package prjCarro;

import java.util.Scanner;

public class Aplicacao {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Qual o marca: ");
		String marca = sc.nextLine();
		
		System.out.println("Qual o modelo: ");
		String modelo = sc.nextLine();
		
		System.out.println("Qual a placa: ");
		String placa = sc.nextLine();
		
		System.out.println("Qual a velocidade do carro: ");
		int V = sc.nextInt();
		
		System.out.println("O que deseja fazer: ");
		System.out.println("1. Acelerar");
		System.out.println("2. Mudar placa");
		int opcao = sc.nextInt();
		
		if (opcao == 1) {
			System.out.println("Quanto deseja acelerar?");
			int valor = sc.nextInt();
			V += valor;
		}
		else if (opcao == 2) {
			System.out.println("Como deseja editar sua placa?");
			int valor = sc.nextInt();
			V -= valor;
		}
		else {
			System.out.println("Opção inválida!");
		}
		
		System.out.println("Marca: " + marca);
		System.out.println("Modelo: " + modelo);
		System.out.println("Placa: " + placa);
		System.out.println("Velocidade: " + V + "Km/h");
		
		sc.close();
	}

}
