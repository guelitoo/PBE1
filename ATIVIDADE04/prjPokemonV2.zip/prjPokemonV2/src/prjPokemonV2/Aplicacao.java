package prjPokemonV2;

public class Aplicacao {

	public static void main(String[] args) {
		
		Pokemon Charmander = new PokemonFogo();

		Charmander.setNome("Charmander");
		Charmander.setTipo("Fogo");
		Charmander.setNivel(1);
		Charmander.setHp(50);
		Charmander.setDefesa(50);
		
		Pokemon Moltres = new PokemonFogo();
		
		Moltres.setNome("Moltres");
		Moltres.setTipo("Fogo");
		Moltres.setNivel(1);
		Moltres.setHp(50);
		Moltres.setDefesa(50);
		
		Pokemon Greninja = new PokemonAgua();
		
		Greninja.setNome("Greninja");
		Greninja.setTipo("Água");
		Greninja.setNivel(1);
		Greninja.setHp(50);
		Greninja.setDefesa(50);
		
		Pokemon Squirtle = new PokemonAgua();
		
		Squirtle.setNome("Squirtle");
		Squirtle.setTipo("Água");
		Squirtle.setNivel(1);
		Squirtle.setHp(50);
		Squirtle.setDefesa(50);
		
		Pokemon Pidgey = new PokemonVoador();
		
		Pidgey.setNome("Pidgey");
		Pidgey.setTipo("Voador");
		Pidgey.setNivel(1);
		Pidgey.setHp(50);
		Pidgey.setDefesa(50);
		
		Pokemon Dragonair = new PokemonVoador();
		
		Dragonair.setNome("Dragonite");
		Dragonair.setTipo("Voador");
		Dragonair.setNivel(1);
		Dragonair.setHp(50);
		Dragonair.setDefesa(50);
		
		Pokemon Loudred = new PokemonComum();
		
		Loudred.setNome("Loudred");
		Loudred.setTipo("Comum");
		Loudred.setNivel(1);
		Loudred.setHp(50);
		Loudred.setDefesa(50);
		
		Pokemon Snorlax = new PokemonComum();
		
		Snorlax.setNome("Snorlax");
		Snorlax.setTipo("Comum");
		Snorlax.setNivel(1);
		Snorlax.setHp(50);
		Snorlax.setDefesa(50);
		
		//Evolução e ataque
		Charmander.evoluir();
		Charmander.atacar();
		
		Moltres.evoluir();
		Moltres.atacar();
		
		Greninja.evoluir();
		Greninja.atacar();
		
		Squirtle.evoluir();
		Squirtle.atacar();
		
		Pidgey.evoluir();
		Pidgey.atacar();
		Pidgey.exibirinfo();
		
		Dragonair.evoluir();
		Dragonair.atacar();
		
		//Exibir informações
		Charmander.exibirinfo();
		
		Moltres.exibirinfo();
		
		Greninja.exibirinfo();
		
		Squirtle.exibirinfo();
		
		Dragonair.exibirinfo();
	}
}
