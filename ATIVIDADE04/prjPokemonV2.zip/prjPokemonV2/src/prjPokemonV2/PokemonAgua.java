package prjPokemonV2;

public class PokemonAgua extends Pokemon {
	
	
	public void surfe() {
		System.out.println(this.getNome() + " surfou!");
	}
	public void canhaoAgua() {
		System.out.println(this.getNome() + " usou canhão de água!");
	}
}
