package prjPokemonV2;

public class PokemonFogo extends Pokemon {
	
	
	public void bolaFogo() {
		System.out.println(this.getNome() + " usou bola de fogo!");
	}
	public void explosaoFogo() {
		System.out.println(this.getNome() + " usou explosão de fogo!");
	}
	public void lancaChamas() {
		System.out.println(this.getNome() + " usou lança chamas!");
	}
	
	
 }
