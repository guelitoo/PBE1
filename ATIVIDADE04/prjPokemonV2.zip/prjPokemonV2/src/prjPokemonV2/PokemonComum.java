package prjPokemonV2;

public class PokemonComum extends Pokemon{
	
	public void atacar() {
		System.out.println(this.getNome() + " usou Ataque basico");
	}
}
