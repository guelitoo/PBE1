package prjPokemonV2;

public class PokemonVoador extends Pokemon {
	
	
	public void ataqueAsa() {
		System.out.println(this.getNome() + " usou Ataque de asa!");
	}
	public void voou() {
		System.out.println(this.getNome() + " voou!");
	}
}
