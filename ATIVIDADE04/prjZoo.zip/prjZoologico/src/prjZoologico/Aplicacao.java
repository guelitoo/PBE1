package prjZoologico;

import java.util.Scanner;

public class Aplicacao {

	public static void main(String[] args) {
		
		//Scanner
		Scanner sc = new Scanner(System.in);
		
		//Instanciamento de classe
		ClasseAnimal elefante = new ClasseAnimal();
		
		//Inicialição de atributos
		elefante.setNome("Dumbo");
		elefante.setPeso(-100);
		
		ClasseAnimal girafa = new ClasseAnimal("GitHub", "Australiana", "Femea", 50);
		
		SubClasseCarnivoros leao = new SubClasseCarnivoros();
		leao.setNome("Fumasa");
		leao.setRaca("Autraliano");
		leao.setSexo("Macho");
		leao.setPeso(200);
		
		leao.medotoCacar();
		
		elefante.exibirInfo();
		elefante.metodoComer(50);
		elefante.metodoExercitar();
		elefante.exibirInfo();
		
		girafa.exibirInfo();
		girafa.metodoEmitirSom();
		
		leao.exibirInfo();
		leao.metodoEmitirSom();
		
		elefante.metodoEmitirSom();

		
	}

}
