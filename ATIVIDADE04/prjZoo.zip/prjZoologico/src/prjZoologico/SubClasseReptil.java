package prjZoologico;

public class SubClasseReptil extends ClasseAnimal {

	//Metodos da SubClasse
	public void metodoTrocarPele() {
		System.out.println(this.atributoNome + " está trocando de pele...");
		System.out.println(this.atributoNome + " trocou de pele!");
	}
	
	@Override
	public void metodoEmitirSom() {
		System.out.println("Ssssssss\n");
	}
}
