package prjZoologico;

public class SubClasseCarnivoros extends ClasseAnimal {
	
	//Metodos da SubClasse
	public void medotoCacar() {
		System.out.println(this.atributoNome + " está caçando.\n");
	}
	
	@Override
	public void metodoEmitirSom() {
		System.out.println("RUUAARRR\n");
	}
	
	
	
	
	
}
