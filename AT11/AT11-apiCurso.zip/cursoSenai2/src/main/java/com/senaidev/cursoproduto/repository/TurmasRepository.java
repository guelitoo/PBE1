package com.senaidev.cursoproduto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senaidev.cursoproduto.entities.Turmas;

public interface TurmasRepository extends JpaRepository<Turmas, Long>{

}
