package com.senaidev.cursoproduto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senaidev.cursoproduto.entities.Instrutores;

public interface InstrutoresRepository extends JpaRepository<Instrutores, Long>{

}
