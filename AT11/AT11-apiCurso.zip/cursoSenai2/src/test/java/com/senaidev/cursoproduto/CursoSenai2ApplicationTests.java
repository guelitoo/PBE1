package com.senaidev.cursoproduto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoSenai2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
