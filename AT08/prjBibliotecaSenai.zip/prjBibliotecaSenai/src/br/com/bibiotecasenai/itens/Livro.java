package br.com.bibiotecasenai.itens;

public class Livro {
	
	//Atributos
	protected String titulo;
	protected String autor;
	protected String isbn;
	protected Boolean disponivel;
	
	//Construtores
	public Livro() {
		
	}
	public Livro(String titulo, String autor, String isbn, Boolean disponivel) {
		this.titulo = titulo;
		this.autor = autor;
		this.isbn = isbn;
		this.disponivel = disponivel;
	}
	
	//Getteers e Setters (Titulo)
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	//Getteers e Setters (Autor)
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	//Getteers e Setters (Isbn)
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	//Getteers e Setters (Disponivel)
	public Boolean getDisponivel() {
		return disponivel;
	}
	public void setDisponivel(Boolean disponivel) {
		this.disponivel = disponivel;
	}
	
}
