package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Bibliotecario;

import br.com.bibiotecasenai.usuarios.Usuario;

public class Aplicacao {

	public static void main(String[] args) {
		
		//Instaciação das Pessoas
		Usuario usuario01 = new Usuario();
		
		Usuario usuario02 = new Usuario();
		
		Bibliotecario usuario03 = new Bibliotecario();
		
		//
		usuario01.setNome("Miguel");
		usuario01.setIdade(16);
		usuario01.setCpf("05459917720");
		usuario01.setLivrosEmprestados();
		
		for (int i = 0; i < 9; i++) {
			usuario01.emprestarLivros(0);
		}
		usuario01.exibirInfo();
		
		for (int i = 0; i < 7; i++) {
			usuario01.devolverLivros(0);
		}
		usuario02.setNome("Murilo");
		usuario02.setIdade(16);
		usuario02.setCpf("73984769798");
		usuario02.setLivrosEmprestados();
		
		for (int i = 0; i < 9; i++) {
			usuario02.emprestarLivros(0);
		}
		usuario02.exibirInfo();
		
		for (int i = 0; i < 7; i++) {
			usuario02.devolverLivros(0);
		}
		usuario03.setNome("Miguel");
		usuario03.setIdade(16);
		usuario03.setCpf("05459917720");
		usuario03.setLivrosEmprestados();
		
		for (int i = 0; i < 9; i++) {
			usuario03.emprestarLivros(0);
		}
		usuario03.exibirInfo();
		
		for (int i = 0; i < 7; i++) {
			usuario03.devolverLivros(0);
		}
		
	}

}
