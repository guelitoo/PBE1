package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa{
	
	//Atributos
	protected Boolean matricula;
	
	//Construtores
	public Bibliotecario() {
	
	}
	public Bibliotecario(Boolean matricula) {
		this.matricula = matricula;
	}

	//Metodos
	public void realizarEmprestimo() {
		
	}
	
	public void devolverLivro() {
		
	}
}
