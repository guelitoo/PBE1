package br.com.bibiotecasenai.usuarios;

public class Usuario extends Pessoa{
	
	//Atributos
	protected String cpf;
	protected int livrosEmprestados;
	
	//Contrutores
	public Usuario() {
		
	}
	public Usuario(String cpf, int livrosEmprestados) {
		this.cpf = cpf;
		this.livrosEmprestados = livrosEmprestados;
	}
	
	//Getters e Setters (CPF)
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	//Getters e Setters (LivrosEmprestados)
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}
	
	
	public void exibirInfo() {
		System.out.println(this.nome);
		System.out.println(this.idade + " anos");
		System.out.println(this.cpf);
		System.out.println("Livros: " + this.livrosEmprestados);
	}
	
	
}
