package br.com.senaimusic.modelos;

public class MinhasPreferidas {
	
	//Metodos
	public void incluir(Audio audio) {
		if(audio.getClassificacao()  >= 9) {
			System.out.println("É de qualidade");
		}
		else {
			System.out.println("😐");
		}
	}
}
