package com.senaidev.cursosenai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursosenaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
